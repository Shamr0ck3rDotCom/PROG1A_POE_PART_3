package com.mycompany.quickchat;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

// The Message class handles everything related to creating, validating,
// sending, storing, and retrieving messages.
public class Message {

    // -------------------------------------------------------------------------
    // Instance Fields — unique to each Message object
    // -------------------------------------------------------------------------

    private String messageID;    // Auto-generated 10-digit ID
    private String recipient;    // Recipient's cell number (must be +27 format)
    private String message;      // Message text (max 250 characters)
    private String messageHash;  // Auto-generated hash e.g. "64:1:HITONIGHT"

    // -------------------------------------------------------------------------
    // Static Arrays — shared across ALL Message objects for the whole session
    // 'static' means one copy exists no matter how many Message objects are made
    // -------------------------------------------------------------------------

    public static List<String> sentMessagesArray      = new ArrayList<>(); // all sent messages
    public static List<String> disregardedMessagesArray = new ArrayList<>(); // all disregarded messages
    public static List<String> storedMessagesArray    = new ArrayList<>(); // loaded from JSON file
    public static List<String> messageHashesArray     = new ArrayList<>(); // all hashes
    public static List<String> messageIDsArray        = new ArrayList<>(); // all IDs

    // Tracks how many messages have been sent this session
    private static int totalMessagesSent = 0;

    // -------------------------------------------------------------------------
    // Constructor — runs every time a new Message is created
    // -------------------------------------------------------------------------

    public Message(String recipient, String message) {
        this.messageID   = generateMessageID(); // generate ID first
        this.recipient   = recipient;
        this.message     = message;
        this.messageHash = createMessageHash(); // hash uses the ID so ID must come first

        // Record the ID and hash for every message created, regardless of what happens to it
        messageIDsArray.add(this.messageID);
        messageHashesArray.add(this.messageHash);
    }

    // -------------------------------------------------------------------------
    // ID Generation
    // -------------------------------------------------------------------------

    // Generates a random 10-digit number as a String e.g. "4823901765"
    // The range 1,000,000,000 to 9,999,999,999 ensures it is always exactly 10 digits
    private String generateMessageID() {
        Random rand = new Random();
        long id = 1_000_000_000L + (long)(rand.nextDouble() * 9_000_000_000L);
        return String.valueOf(id);
    }

    // -------------------------------------------------------------------------
    // Validation Methods
    // -------------------------------------------------------------------------

    // Returns true if the message ID is 10 characters or fewer
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Validates the recipient number using regex pattern \+27[0-9]{9}
    //   \\+27    → must start with +27 (SA country code)
    //   [0-9]{9} → followed by exactly 9 digits
    // Returns a success or failure message as a String
    public String checkRecipientCell() {
        if (recipient.matches("\\+27[0-9]{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an " +
               "international code. Please correct the number and try again.";
    }

    // Checks the message is within the 250-character limit
    // Returns success or an error showing how many characters over the limit
    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        }
        int excess = message.length() - 250;
        return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
    }

    // -------------------------------------------------------------------------
    // Hash Generation
    // -------------------------------------------------------------------------

    // Builds the hash in the format: XX:N:FIRSTLAST (all caps)
    //   XX        = first two digits of the message ID
    //   N         = this message's number (totalMessagesSent + 1)
    //   FIRSTLAST = first and last words of the message joined together
    // Example: "64:1:HITONIGHT"
    public String createMessageHash() {
        String idPrefix  = messageID.substring(0, 2);
        String[] words   = message.trim().split("\\s+"); // split message into words
        String firstWord = words[0];
        String lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", ""); // strip punctuation
        int messageNumber = totalMessagesSent + 1;
        return (idPrefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // -------------------------------------------------------------------------
    // Send / Disregard / Store
    // -------------------------------------------------------------------------

    // Handles the user's chosen action:
    //   1 = Send      → adds to sentMessagesArray, increments counter
    //   2 = Disregard → adds to disregardedMessagesArray
    //   3 = Store     → saves to JSON file and adds to storedMessagesArray
    public String SentMessage(int choice) {
        // Build a reusable summary string for this message
        String summary = "Message ID: "   + messageID   + "\n" +
                         "Message Hash: " + messageHash + "\n" +
                         "Recipient: "    + recipient   + "\n" +
                         "Message: "      + message;

        switch (choice) {
            case 1: // Send
                totalMessagesSent++;
                sentMessagesArray.add(summary);
                return "Message successfully sent.";

            case 2: // Disregard
                disregardedMessagesArray.add(summary);
                return "Press 0 to delete the message.";

            case 3: // Store
                storeMessage();
                storedMessagesArray.add(summary);
                return "Message successfully stored.";

            default:
                return "Invalid option.";
        }
    }

    // -------------------------------------------------------------------------
    // JSON File Methods
    // -------------------------------------------------------------------------

    // Saves this message to stored_messages.json
    // If the file already exists, the new message is appended — not overwritten
    public void storeMessage() {
        try {
            File file = new File("stored_messages.json");
            JSONArray jsonArray = new JSONArray();

            // Load existing messages so we don't overwrite them
            if (file.exists()) {
                String existing = new String(java.nio.file.Files.readAllBytes(file.toPath()));
                if (!existing.isBlank()) jsonArray = new JSONArray(existing);
            }

            // Add this message as a new JSON object
            JSONObject obj = new JSONObject();
            obj.put("messageID",   messageID);
            obj.put("messageHash", messageHash);
            obj.put("recipient",   recipient);
            obj.put("message",     message);
            jsonArray.put(obj);

            // Write back to file with 2-space indentation for readability
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(jsonArray.toString(2));
            }
        } catch (Exception e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // Reads stored_messages.json and loads all entries into storedMessagesArray
    // Called when the app starts and when the Stored Messages menu is opened
    public static void loadStoredMessages() {
        storedMessagesArray.clear(); // clear old data before reloading
        try {
            File file = new File("stored_messages.json");
            if (!file.exists()) return;

            String content = new String(java.nio.file.Files.readAllBytes(file.toPath()));
            if (content.isBlank()) return;

            JSONArray jsonArray = new JSONArray(content);

            // Convert each JSON object into a summary string and add to the array
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                storedMessagesArray.add(
                    "Message ID: "   + obj.getString("messageID")   + "\n" +
                    "Message Hash: " + obj.getString("messageHash") + "\n" +
                    "Recipient: "    + obj.getString("recipient")   + "\n" +
                    "Message: "      + obj.getString("message")
                );
            }
        } catch (Exception e) {
            System.out.println("Error loading stored messages: " + e.getMessage());
        }
    }

    // Deletes a stored message from the JSON file that matches the given hash
    // Rewrites the file without the deleted message and reloads the array
    public static String deleteStoredMessage(String hash) {
        try {
            File file = new File("stored_messages.json");
            if (!file.exists()) return "No stored messages found.";

            JSONArray jsonArray = new JSONArray(
                new String(java.nio.file.Files.readAllBytes(file.toPath()))
            );
            JSONArray updatedArray = new JSONArray(); // will hold everything except the deleted message
            boolean found = false;
            String deletedMessage = "";

            // Loop through all messages — skip the one matching the hash
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                if (obj.getString("messageHash").equalsIgnoreCase(hash)) {
                    found = true;
                    deletedMessage = obj.getString("message");
                } else {
                    updatedArray.put(obj); // keep all other messages
                }
            }

            if (!found) return "Message with hash " + hash + " not found.";

            // Write the updated array (without the deleted message) back to file
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(updatedArray.toString(2));
            }

            loadStoredMessages(); // refresh the in-memory array
            return "Message: \"" + deletedMessage + "\" successfully deleted.";

        } catch (Exception e) {
            return "Error deleting message: " + e.getMessage();
        }
    }

    // -------------------------------------------------------------------------
    // Static Helpers
    // -------------------------------------------------------------------------

    // Returns all sent messages as one formatted String
    public static String printMessages() {
        if (sentMessagesArray.isEmpty()) return "No messages have been sent.";
        return String.join("\n\n", sentMessagesArray);
    }

    // Returns the total number of messages sent this session
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Resets all static data — only called by unit tests so each test starts fresh
    public static void resetState() {
        totalMessagesSent = 0;
        sentMessagesArray.clear();
        disregardedMessagesArray.clear();
        storedMessagesArray.clear();
        messageHashesArray.clear();
        messageIDsArray.clear();
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public String getMessageID()   { return messageID; }
    public String getRecipient()   { return recipient; }
    public String getMessage()     { return message; }
    public String getMessageHash() { return messageHash; }
}