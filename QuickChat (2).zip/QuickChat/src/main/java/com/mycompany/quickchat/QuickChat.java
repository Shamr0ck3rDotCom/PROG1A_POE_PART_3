package com.mycompany.quickchat;

import java.util.Scanner;

// QuickChat is the main class — it controls the flow of the entire application.
// It handles registration, login, the main menu, and all messaging features.
public class QuickChat {

    // One Scanner for the whole class so we never open duplicate input streams
    private static Scanner scanner = new Scanner(System.in);

    // Holds the registered user — set during registration, used during login
    private static Login registeredUser = null;

    // -------------------------------------------------------------------------
    // Entry Point
    // -------------------------------------------------------------------------

    public static void main(String[] args) {
        System.out.println("=== Welcome to QuickChat ===");

        // Step 1: Register — user cannot proceed until all fields are valid
        registeredUser = registerFlow();

        // Step 2: Login — user cannot proceed until credentials are correct
        if (!loginFlow()) return;

        // Step 3: Load any previously stored messages from the JSON file
        Message.loadStoredMessages();

        // Step 4: Ask how many messages the user wants to send this session
        int numMessages = askNumMessages();
        if (numMessages < 0) return;

        // Step 5: Run the main menu until the user quits
        runMainMenu(numMessages);

        // Step 6: Show a full session summary on exit
        System.out.println("\nTotal messages sent: " + Message.returnTotalMessagess());
        System.out.println("\n--- All Sent Messages ---");
        System.out.println(Message.printMessages());
    }

    // -------------------------------------------------------------------------
    // Registration Flow
    // -------------------------------------------------------------------------

    // Walks the user through creating an account.
    // Each field loops until the user enters a valid value.
    // Returns the completed Login object once all fields are valid.
    private static Login registerFlow() {
        System.out.println("\n--- Create Your Account ---");

        // Collect name — no validation rules specified for these fields
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine().trim();

        // Username loop — keep asking until the username passes checkUserName()
        String username = "";
        while (true) {
            System.out.print("Enter username (must contain '_' and be max 5 characters e.g. kyl_1): ");
            username = scanner.nextLine().trim();
            Login temp = new Login(firstName, lastName, username, "Placeholder1!", "+27000000000");
            if (temp.checkUserName()) {
                System.out.println("Username successfully captured.");
                break;
            }
            // Tell the user exactly what the username rule requires
            System.out.println("Username is not correctly formatted; please ensure that your " +
                "username contains an underscore and is no more than five characters in length.");
        }

        // Password loop — keep asking until the password passes checkPasswordComplexity()
        String password = "";
        while (true) {
            System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special character e.g. Ch&&sec@ke99!): ");
            password = scanner.nextLine().trim();
            Login temp = new Login(firstName, lastName, username, password, "+27000000000");
            if (temp.checkPasswordComplexity()) {
                System.out.println("Password successfully captured.");
                break;
            }
            // Remind the user of all four password rules
            System.out.println("Password is not correctly formatted; please ensure that the " +
                "password contains at least eight characters, a capital letter, a number, and a special character.");
        }

        // Cell number loop — keep asking until the number passes checkCellPhoneNumber()
        String cellNumber = "";
        while (true) {
            System.out.print("Enter SA cell number (must start with +27 e.g. +27838968976): ");
            cellNumber = scanner.nextLine().trim();
            Login temp = new Login(firstName, lastName, username, password, cellNumber);
            if (temp.checkCellPhoneNumber()) {
                System.out.println("Cell phone number successfully added.");
                break;
            }
            // Show the required format
            System.out.println("Cell phone number incorrectly formatted or does not contain " +
                "international code. Must start with +27 followed by 9 digits.");
        }

        // All fields are valid — build and return the final Login object
        Login newUser = new Login(firstName, lastName, username, password, cellNumber);
        System.out.println("\nRegistration successful! Welcome, " + firstName + " " + lastName + ".");
        return newUser;
    }

    // -------------------------------------------------------------------------
    // Login Flow
    // -------------------------------------------------------------------------

    // Prompts the user to log in with their registered credentials.
    // Allows up to 3 attempts before locking out.
    // Returns true on success, false after 3 failed attempts.
    private static boolean loginFlow() {
        System.out.println("\n--- Login ---");
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine().trim();
            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine().trim();

            // Print the result — "Welcome..." on success or error message on failure
            System.out.println(registeredUser.returnLoginStatus(enteredUsername, enteredPassword));

            if (registeredUser.loginUser(enteredUsername, enteredPassword)) {
                return true; // login succeeded
            }

            // Show hints and remaining attempts after each failure
            int remaining = maxAttempts - attempt;
            if (remaining > 0) {
                System.out.println("Attempts remaining: " + remaining);
                System.out.println("Hint — Username: must contain '_' and be max 5 characters.");
                System.out.println("Hint — Password: min 8 chars, 1 capital, 1 number, 1 special character.");
            }
        }

        System.out.println("Too many failed attempts. Exiting.");
        return false;
    }

    // -------------------------------------------------------------------------
    // Setup
    // -------------------------------------------------------------------------

    // Asks how many messages to send this session — returns -1 on invalid input
    private static int askNumMessages() {
        System.out.print("\nHow many messages would you like to send? ");
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Exiting.");
            return -1;
        }
    }

    // -------------------------------------------------------------------------
    // Main Menu
    // -------------------------------------------------------------------------

    // Shows the main menu and handles the user's choice.
    // Loops until the user selects option 4 (Quit).
    private static void runMainMenu(int numMessages) {
        boolean running = true;
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            System.out.print("Choose an option: ");

            switch (scanner.nextLine().trim()) {
                case "1": sendMessages(numMessages); break;
                case "2": showRecentlySentMessages(); break;
                case "3": storedMessagesMenu(); break;
                case "4": running = false; System.out.println("Goodbye!"); break;
                default:  System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // -------------------------------------------------------------------------
    // Message Sending Flow
    // -------------------------------------------------------------------------

    // Loops through the number of messages requested.
    // For each: collects input, validates it, then asks what to do with it.
    private static void sendMessages(int numMessages) {
        for (int i = 0; i < numMessages; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + numMessages + " ---");

            System.out.print("Enter recipient cell number (e.g. +27718693002): ");
            String recipient = scanner.nextLine().trim();

            System.out.print("Enter your message (max 250 characters): ");
            String messageText = scanner.nextLine();

            // Create the Message object — ID and hash are auto-generated inside
            Message msg = new Message(recipient, messageText);

            System.out.println("Message ID generated: " + msg.getMessageID());
            System.out.println(msg.checkRecipientCell());
            System.out.println(msg.checkMessageLength());

            // If too long, step back and retry this slot
            if (messageText.length() > 250) { i--; continue; }

            System.out.println("Message Hash: " + msg.getMessageHash());

            // Ask what to do: Send, Disregard, or Store
            int action = askMessageAction();
            System.out.println(msg.SentMessage(action));

            // Print full details if the message was sent
            if (action == 1) {
                System.out.println("\nMessage ID: "  + msg.getMessageID());
                System.out.println("Message Hash: " + msg.getMessageHash());
                System.out.println("Recipient: "    + msg.getRecipient());
                System.out.println("Message: "      + msg.getMessage());
            }
        }
    }

    // Shows the Send / Disregard / Store sub-menu and returns the user's choice
    private static int askMessageAction() {
        System.out.println("\n1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message");
        System.out.print("Choose: ");
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Disregarding message.");
            return 2;
        }
    }

    // -------------------------------------------------------------------------

    // Displays all messages sent during this session.
    // Shows the full details of each sent message: ID, hash, recipient, and message text.
    // Called when the user selects option 2 from the main menu.
    private static void showRecentlySentMessages() {
        if (Message.sentMessagesArray.isEmpty()) {
            System.out.println("No messages have been sent yet.");
            return;
        }
        System.out.println("\n--- Recently Sent Messages ---");
        for (int i = 0; i < Message.sentMessagesArray.size(); i++) {
            System.out.println("\nMessage " + (i + 1) + ":");
            System.out.println(Message.sentMessagesArray.get(i));
        }
    }

    // Part 3 — Stored Messages Menu
    // -------------------------------------------------------------------------

    // Shows the Stored Messages sub-menu with all 6 options from the assignment.
    // Reloads the JSON file each time it opens so data is always current.
    private static void storedMessagesMenu() {
        Message.loadStoredMessages();
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\n--- Stored Messages Menu ---");
            System.out.println("a) Display recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message by ID");
            System.out.println("d) Search all messages for a particular recipient");
            System.out.println("e) Delete a message using its hash");
            System.out.println("f) Display full report of all stored messages");
            System.out.println("g) Back to main menu");
            System.out.print("Choose an option: ");

            switch (scanner.nextLine().trim().toLowerCase()) {
                case "a": displayStoredRecipients(); break;
                case "b": displayLongestMessage();   break;
                case "c": searchByMessageID();       break;
                case "d": searchByRecipient();       break;
                case "e": deleteByHash();            break;
                case "f": displayFullReport();       break;
                case "g": inMenu = false;            break;
                default:  System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Option a: Print the Recipient line from every stored message
    private static void displayStoredRecipients() {
        if (Message.storedMessagesArray.isEmpty()) { System.out.println("No stored messages found."); return; }
        System.out.println("\n--- Recipients of Stored Messages ---");
        for (String summary : Message.storedMessagesArray)
            for (String line : summary.split("\n"))
                if (line.startsWith("Recipient:")) System.out.println(line);
    }

    // Option b: Find and print the message with the most characters
    private static void displayLongestMessage() {
        if (Message.storedMessagesArray.isEmpty()) { System.out.println("No stored messages found."); return; }
        String longest = "";
        for (String summary : Message.storedMessagesArray)
            for (String line : summary.split("\n"))
                if (line.startsWith("Message:")) {
                    String text = line.substring("Message: ".length());
                    if (text.length() > longest.length()) longest = text;
                }
        System.out.println("\nLongest stored message: " + longest);
    }

    // Option c: Search stored messages by ID and print the recipient + message
    private static void searchByMessageID() {
        System.out.print("Enter Message ID to search: ");
        String searchID = scanner.nextLine().trim();
        boolean found = false;
        for (String summary : Message.storedMessagesArray)
            if (summary.contains("Message ID: " + searchID)) {
                for (String line : summary.split("\n"))
                    if (line.startsWith("Recipient:") || line.startsWith("Message:"))
                        System.out.println(line);
                found = true; break;
            }
        if (!found) System.out.println("No message found with ID: " + searchID);
    }

    // Option d: Print all stored messages that match the given recipient number
    private static void searchByRecipient() {
        System.out.print("Enter recipient number to search: ");
        String searchRecipient = scanner.nextLine().trim();
        boolean found = false;
        for (String summary : Message.storedMessagesArray)
            if (summary.contains("Recipient: " + searchRecipient)) {
                System.out.println("\n" + summary); found = true;
            }
        if (!found) System.out.println("No messages found for recipient: " + searchRecipient);
    }

    // Option e: Delete a stored message from the file using its hash
    private static void deleteByHash() {
        System.out.print("Enter the Message Hash to delete: ");
        System.out.println(Message.deleteStoredMessage(scanner.nextLine().trim()));
    }

    // Option f: Print the full details of every stored message
    private static void displayFullReport() {
        if (Message.storedMessagesArray.isEmpty()) { System.out.println("No stored messages to report."); return; }
        System.out.println("\n========== STORED MESSAGES REPORT ==========");
        for (int i = 0; i < Message.storedMessagesArray.size(); i++) {
            System.out.println("\n--- Message " + (i + 1) + " ---");
            for (String line : Message.storedMessagesArray.get(i).split("\n"))
                if (line.startsWith("Message Hash:") || line.startsWith("Recipient:") || line.startsWith("Message:"))
                    System.out.println(line);
        }
        System.out.println("\n=============================================");
    }
}