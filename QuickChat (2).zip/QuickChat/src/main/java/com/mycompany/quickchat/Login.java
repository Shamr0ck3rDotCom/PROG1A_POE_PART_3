package com.mycompany.quickchat;

// The Login class handles all registration and login functionality.
// It stores the user's details and validates them against the assignment rules.
public class Login {

    // -------------------------------------------------------------------------
    // Fields — the user's registered details
    // -------------------------------------------------------------------------

    private String firstName;       // Used in the welcome message after login
    private String lastName;        // Used in the welcome message after login
    private String username;        // Must contain '_' and be no more than 5 characters
    private String password;        // Must have 8+ chars, a capital, a number, a special character
    private String cellPhoneNumber; // Must start with +27 followed by exactly 9 digits

    // -------------------------------------------------------------------------
    // Constructor — called when a new Login object is created during registration
    // -------------------------------------------------------------------------

    public Login(String firstName, String lastName, String username,
                 String password, String cellPhoneNumber) {
        this.firstName       = firstName;
        this.lastName        = lastName;
        this.username        = username;
        this.password        = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // -------------------------------------------------------------------------
    // Validation Methods
    // -------------------------------------------------------------------------

    // Checks the username meets both rules:
    //   1. Contains an underscore character '_'
    //   2. Is no more than 5 characters long
    // Example: "kyl_1" → true  |  "kyle!!!!!!!" → false
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    // Checks the password meets all four complexity rules:
    //   1. At least 8 characters long
    //   2. Contains at least one capital letter    e.g. 'C'
    //   3. Contains at least one number            e.g. '9'
    //   4. Contains at least one special character e.g. '@'
    // Example: "Ch&&sec@ke99!" → true  |  "password" → false
    public boolean checkPasswordComplexity() {
        return password.length() >= 8              // rule 1: length
            && password.matches(".*[A-Z].*")       // rule 2: capital letter
            && password.matches(".*[0-9].*")       // rule 3: number
            && password.matches(".*[^a-zA-Z0-9].*"); // rule 4: special character
    }

    // Checks the cell number using a regex pattern:
    //   \\+27      → must start with +27 (South African country code)
    //   [0-9]{9}   → followed by exactly 9 digits
    // Example: "+27838968976" → true  |  "08966553" → false
    // Regex reference: https://www.baeldung.com/java-regex-validate-phone-numbers
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber.matches("\\+27[0-9]{9}");
    }

    // -------------------------------------------------------------------------
    // Registration
    // -------------------------------------------------------------------------

    // Validates all three fields and returns the appropriate message.
    // Checks are done in order: username → password → cell number.
    // Returns the exact messages specified in the assignment.
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username " +
                   "contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password " +
                   "contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        // All three checks passed
        return "Username successfully captured.\n" +
               "Password successfully captured.\n" +
               "Cell phone number successfully added.\n" +
               "Registration successful! Welcome, " + firstName + " " + lastName + ".";
    }

    // -------------------------------------------------------------------------
    // Login
    // -------------------------------------------------------------------------

    // Returns true if the entered username AND password both match the registered details.
    // Returns false if either one is wrong.
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    // Returns the correct message based on whether login succeeded or failed:
    //   Success → "Welcome <first name>, <last name> it is great to see you again."
    //   Failure → "Username or password incorrect, please try again."
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    // -------------------------------------------------------------------------
    // Getters — allow other classes to read the private fields
    // -------------------------------------------------------------------------

    public String getFirstName()       { return firstName; }
    public String getLastName()        { return lastName; }
    public String getUsername()        { return username; }
    public String getCellPhoneNumber() { return cellPhoneNumber; }
}