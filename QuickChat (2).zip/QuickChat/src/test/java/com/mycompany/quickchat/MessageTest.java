package com.mycompany.quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Message class — covers Part 2 and Part 3 requirements.
 *
 * Part 3 Test Data (from assignment):
 *   Message 1: +27834557896 / "Did you get the cake?"         / Flag: Sent
 *   Message 2: +27838884567 / "Where are you? You are late! I have asked you to be on time." / Flag: Stored
 *   Message 3: +27834484567 / "Yohoooo, I am at your gate."   / Flag: Disregard
 *   Message 4: 0838884567   / "It is dinner time !"           / Flag: Sent
 *   Message 5: +27838884567 / "Ok, I am leaving without you." / Flag: Stored
 */
public class MessageTest {

    // -------------------------------------------------------------------------
    // Part 2 test objects (used in the original tests)
    // -------------------------------------------------------------------------
    private Message message1; // valid recipient — Task 1
    private Message message2; // invalid recipient — Task 2

    // -------------------------------------------------------------------------
    // Part 3 test objects (one per test message in the assignment)
    // -------------------------------------------------------------------------
    private Message msg1; // Sent
    private Message msg2; // Stored
    private Message msg3; // Disregarded
    private Message msg4; // Sent (invalid number)
    private Message msg5; // Stored

    // @BeforeEach runs before EVERY test to ensure a completely clean state
    // This prevents one test's data from affecting another test's result
    @BeforeEach
    public void setUp() {
        // Reset all static arrays and counters in Message
        Message.resetState();

        // --- Part 2 messages ---
        message1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        message2 = new Message("08575975889",  "Hi Keegan, did you receive the payment?");

        // --- Part 3 messages (using the assignment's test data) ---
        msg1 = new Message("+27834557896", "Did you get the cake?");
        msg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        msg3 = new Message("+27834484567", "Yohoooo, I am at your gate.");
        msg4 = new Message("0838884567",   "It is dinner time !");
        msg5 = new Message("+27838884567", "Ok, I am leaving without you.");

        // Apply the flags from the assignment test data
        msg1.SentMessage(1); // Sent
        msg2.SentMessage(3); // Stored
        msg3.SentMessage(2); // Disregarded
        msg4.SentMessage(1); // Sent
        msg5.SentMessage(3); // Stored
    }

    // =========================================================================
    // PART 2 TESTS
    // =========================================================================

    // --- checkMessageID ---

    @Test
    public void testCheckMessageID_isNotMoreThan10Chars() {
        assertTrue(message1.checkMessageID(), "Message ID should be 10 characters or fewer");
    }

    @Test
    public void testCheckMessageID_isNotNullOrEmpty() {
        assertNotNull(message1.getMessageID());
        assertFalse(message1.getMessageID().isBlank());
    }

    // --- checkRecipientCell ---

    @Test
    public void testCheckRecipientCell_success() {
        assertEquals("Cell phone number successfully captured.", message1.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCell_failure() {
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an " +
            "international code. Please correct the number and try again.",
            message2.checkRecipientCell()
        );
    }

    // --- checkMessageLength ---

    @Test
    public void testMessageLength_success() {
        assertEquals("Message ready to send.", message1.checkMessageLength());
    }

    @Test
    public void testMessageLength_failure() {
        // 260 characters — 10 over the limit
        Message longMsg = new Message("+27718693002", "A".repeat(260));
        assertTrue(longMsg.checkMessageLength().startsWith("Message exceeds 250 characters by"));
    }

    // --- createMessageHash ---

    @Test
    public void testMessageHash_correctFormat() {
        // Hash must match XX:N:WORDS — all uppercase
        assertTrue(
            message1.getMessageHash().matches("[A-Z0-9]+:[0-9]+:[A-Z]+"),
            "Hash format invalid: " + message1.getMessageHash()
        );
    }

    @Test
    public void testMessageHash_task1_endsWithHiTonight() {
        // "Hi Mike, can you join us for dinner tonight?" → HITONIGHT
        assertTrue(
            message1.getMessageHash().endsWith(":HITONIGHT"),
            "Expected :HITONIGHT, got: " + message1.getMessageHash()
        );
    }

    @Test
    public void testMessageHash_task2_endsWithHiPayment() {
        // "Hi Keegan, did you receive the payment?" → HIPAYMENT
        assertTrue(
            message2.getMessageHash().endsWith(":HIPAYMENT"),
            "Expected :HIPAYMENT, got: " + message2.getMessageHash()
        );
    }

    // --- SentMessage ---

    @Test
    public void testSentMessage_send() {
        assertEquals("Message successfully sent.", message1.SentMessage(1));
    }

    @Test
    public void testSentMessage_disregard() {
        assertEquals("Press 0 to delete the message.", message1.SentMessage(2));
    }

    @Test
    public void testSentMessage_store() {
        assertEquals("Message successfully stored.", message1.SentMessage(3));
    }

    // --- returnTotalMessagess ---

    @Test
    public void testTotalMessages_doesNotIncrementOnDisregard() {
        // After setUp(), msg1 and msg4 were sent (2 total), msg3 was disregarded
        // Disregarding should not add to the count
        assertEquals(2, Message.returnTotalMessagess(), "Counter should be 2 — only sent messages count");
    }

    // =========================================================================
    // PART 3 TESTS
    // =========================================================================

    // --- Test: Sent Messages array is correctly populated ---
    // The assignment specifies sent messages should contain msg1 and msg4's messages
    // "Did you get the cake?" and "It is dinner time!"
    @Test
    public void testSentMessagesArray_containsCorrectMessages() {
        // Check that the sent array has exactly 2 entries (msg1 and msg4 were sent)
        assertEquals(2, Message.sentMessagesArray.size(),
            "Sent array should contain 2 messages");

        // Check the first sent message contains the correct text
        assertTrue(Message.sentMessagesArray.get(0).contains("Did you get the cake?"),
            "First sent message should be 'Did you get the cake?'");

        // Check the second sent message contains the correct text
        assertTrue(Message.sentMessagesArray.get(1).contains("It is dinner time !"),
            "Second sent message should be 'It is dinner time !'");
    }

    // --- Test: Disregarded Messages array is correctly populated ---
    @Test
    public void testDisregardedMessagesArray_containsCorrectMessage() {
        // Only msg3 was disregarded
        assertEquals(1, Message.disregardedMessagesArray.size(),
            "Disregarded array should contain 1 message");

        assertTrue(Message.disregardedMessagesArray.get(0).contains("Yohoooo, I am at your gate."),
            "Disregarded message should be 'Yohoooo, I am at your gate.'");
    }

    // --- Test: Stored Messages array is correctly populated ---
    @Test
    public void testStoredMessagesArray_containsCorrectMessages() {
        // msg2 and msg5 were stored
        assertEquals(2, Message.storedMessagesArray.size(),
            "Stored array should contain 2 messages");

        assertTrue(Message.storedMessagesArray.get(0).contains(
            "Where are you? You are late! I have asked you to be on time."),
            "First stored message text does not match");

        assertTrue(Message.storedMessagesArray.get(1).contains("Ok, I am leaving without you."),
            "Second stored message text does not match");
    }

    // --- Test: Display the longest message ---
    // Across all 5 test messages, msg2 is the longest:
    // "Where are you? You are late! I have asked you to be on time."
    @Test
    public void testLongestMessage_isMsg2() {
        // Find the longest message across the stored messages array
        String longest = "";
        for (String summary : Message.storedMessagesArray) {
            for (String line : summary.split("\n")) {
                if (line.startsWith("Message:")) {
                    String text = line.substring("Message: ".length());
                    if (text.length() > longest.length()) longest = text;
                }
            }
        }
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest,
            "The longest message should be msg2"
        );
    }

    // --- Test: Search for a message by ID returns the correct message ---
    // msg4 has recipient "0838884567" and message "It is dinner time !"
    @Test
    public void testSearchByMessageID_returnsCorrectMessage() {
        String searchID = msg4.getMessageID();
        boolean found = false;
        for (String summary : Message.sentMessagesArray) {
            if (summary.contains("Message ID: " + searchID)) {
                assertTrue(summary.contains("It is dinner time !"),
                    "Message found by ID should contain 'It is dinner time !'");
                found = true;
                break;
            }
        }
        assertTrue(found, "Message with ID " + searchID + " should be found in sent array");
    }

    // --- Test: Search by recipient returns all matching messages ---
    // +27838884567 appears in msg2 (stored) and msg5 (stored)
    @Test
    public void testSearchByRecipient_returnsAllMatches() {
        String searchRecipient = "+27838884567";
        int count = 0;
        for (String summary : Message.storedMessagesArray) {
            if (summary.contains("Recipient: " + searchRecipient)) {
                count++;
            }
        }
        // Both msg2 and msg5 were stored with this recipient
        assertEquals(2, count, "There should be 2 stored messages for recipient +27838884567");
    }

    // --- Test: Message hashes array is populated for all messages ---
    @Test
    public void testMessageHashesArray_isPopulated() {
        // All 5 messages (plus the 2 from Part 2 setUp) should have hashes recorded
        // Part 2: message1, message2 = 2 entries
        // Part 3: msg1–msg5 = 5 entries
        // Total = 7
        assertEquals(7, Message.messageHashesArray.size(),
            "Hash array should contain one entry per message created");
    }

    // --- Test: Message IDs array is populated for all messages ---
    @Test
    public void testMessageIDsArray_isPopulated() {
        // Same logic as hashes — one ID per message created = 7 total
        assertEquals(7, Message.messageIDsArray.size(),
            "ID array should contain one entry per message created");
    }

    // --- Test: Delete a stored message by hash ---
    @Test
    public void testDeleteStoredMessage_removesCorrectMessage() {
        // Get msg2's hash — this is the message we want to delete
        String hashToDelete = msg2.getMessageHash();

        // Perform the deletion
        String result = Message.deleteStoredMessage(hashToDelete);

        // The result should confirm the deletion with the message text
        assertTrue(result.contains("successfully deleted"),
            "Delete result should confirm deletion. Got: " + result);
    }
}